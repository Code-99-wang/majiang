package life.majiang.community.exception;

/**
 * Created by codedrinker on 2019/5/28.
 */
public interface ICustomizeErrorCode {
    String getMessage() ;
    Integer getCode();
}
