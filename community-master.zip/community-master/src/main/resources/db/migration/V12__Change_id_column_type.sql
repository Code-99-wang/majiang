alter table question modify id bigint auto_increment not null;
alter table `user` modify id bigint auto_increment not null